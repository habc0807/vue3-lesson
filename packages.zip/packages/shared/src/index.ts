export function isObject(value: object) {
    return typeof value === 'object' && value !== null;
}