import { activeEffect, trackEffect, trackEffects } from "./effect";

const targetMap = new WeakMap(); // 不会出现内存泄露

export const createDep = (cleanup: Function, key: any) => {
    const dep = new Map();
    dep.cleanup = cleanup;
    dep.name = key; // 自定义的微了标识这个映射表是给那个属性服务的
    return dep;
}

/**
 *  当前的那个对象那个属性 对应了哪些effect
 * @param target 
 * @param key 
 */
export function track(target : any, key : any) {
    // activeEffect 有这个属性 说明这个key是在effect中被访问的 没有说明在effect外面被访问的
    if (activeEffect) {

        let depsMap = targetMap.get(target);
        if (!depsMap) {
            targetMap.set(target, (depsMap = new Map()))
        }

        let dep = depsMap.get(key)

        if (!dep) { 
            depsMap.set(
                key,
                dep = createDep(() => depsMap.delete(key), key) ,// 这个dep的cleanup函数是用来删除这个key的dep
            )
        }

        trackEffect(activeEffect, dep); // 将当前的Effect放入到dep（映射表）中，后续可以根据值的变化触发此dep中存放的effect
        debugger
        console.log(targetMap)
        // console.log(target,key, activeEffect)
    }
}

export function trigger(target, key, value, oldValue) { 
    const depsMap = targetMap.get(target);
    if (!depsMap) { // 找不到对象 直接return
        return;
    }

    let dep = depsMap.get(key);
    if(dep  && dep.has(activeEffect)) { // 说明这个key在当前的eff
        trackEffects(dep);
    }
}


// Map: { obj: { name: "xxx", age: 15 } }
// {
//     { name: "xxx", age: 15 } : {
//         age: {
//             effect: 0,
//             effect: 0,
//         },
//         name: { 
//             effect, effect
//         }
//     }
// }