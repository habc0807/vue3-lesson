/**
 * 1.reactive 只做了一件事，就是将对象转成响应式的。
 * 
 * 2.怎么变成响应式的 核心就是new Proxy拦截代理
 * 
 * 3.但是我们要防止一个对象被重复的代理，所以将每一个响应式的对象都放到缓存下次在取值的时候 如果缓存里有直接取出来用
 * 
 * 4.还有如果被返回的代理的对象 我就看看它没有私有IS_REACTIVE属性，如果它代理过了，有这个属性，就直接反馈
 */

import { isObject } from "@vue/shared";
import { mutableHandlers, ReactiveFlags } from "./baseHandler";

// 为了预防同一个对象被响应式多次，也就是多次new proxy 做一个缓存，用于存储响应式的对象。 
// 用targetMap来记录我们代理后的结果，可以复用
const reactiveMap = new WeakMap();

/**
 * 对象是否是对象 是否被响应式 是否有缓存
 * @param target 
 * @returns 
 */
function createReactiveObject(target: object) {
    // 统一做判断，响应式对象必须是对象才可以，所以基础数据类型需要先转成对象上的value???
    if (!isObject(target)) {
        return target;
    }

    // 这个枚举的类型是怎么设置上的？第一次没代理之前target上没有get, if之后是个false, 被代理之后才有get，其实是通过访问属性，target[ReactiveFlags.IS_REACTIVE] 就能命中target上的get方法
    // 首次取不到target[ReactiveFlags.IS_REACTIVE]，被代理之后，才能取到，如果取到了 证明已经被代理 直接返回这个的对象
    if ((target as any)[ReactiveFlags.IS_REACTIVE]) {
        return target;
    }

    // 取缓存，如果有缓存 直接返回
    const exitsProxy = reactiveMap.get(target);
    if (exitsProxy) {
        return exitsProxy;
    }

    let proxy = new Proxy(target, mutableHandlers);
    // 给这个要代理的对象目标target 存一个代理后的结果
    reactiveMap.set(target, proxy);
    return proxy;
}


// reactive // shallowReactive // readonly // shallowReadonly
export function reactive(target: object) {
    return createReactiveObject(target);
}

// ??? todo
// export function shallowReactive(target: object) {
//     return createReactiveObject(target, true);
// }