/**
 * 1. 通过用户传递的执行函数，创建响应式effect？？？ 什么是响应式effect
 * 2. 响应式的的effect默认会先执行一次，然后再监听依赖的属性变化，如果变化了，就再执行一次 有点类似watch
 * 
 * 3.为了防止依赖嵌套，在依赖收集的时候，永远是自己，所以先把父亲保存起来，把自己放在全局上，等自己执行完之后，再把父亲设置回去。
 * @param fn 
 * @param options 
 * @returns 
 */

function preCleanEffect(effect: any) {
    effect._depsLength = 0; // 依赖的属性长度清零
    effect._trackId++; // 依赖收集 虽然用到了 state.name 3次 但是不需要在依赖的属性里重复收集 每次执行ID 都是加1，如果当前同一个effect执行 ID就是相同的 state.flag ? state.name + state.name + state.name : state.age; 
}


export function effect(fn: Function, options?: any) {
    // 创建一个响应式effect 数据变化后可以重新执行
    //  创建之后每次fn里的数据变了，我就应该让它重新执行
    // 创建一个effect 只要fn里依赖的属性变化了，就要执行回调
    const _effect = new ReactiveEffect(fn, () => {
        // scheduler 丝改弟有了 是一个回调函数，在数据变化后，会调用这个回调函数，让effect重新执行
        _effect.run()
    })
    _effect.run()

    return _effect
}

export let activeEffect: ReactiveEffect | undefined;

function postCleanEffect(effect: any) { 
    if (effect.deps._depsLength > effect._depsLength) { 
        for(let i = effect._depsLength; i < effect.deps._depsLength; i++) {
            cleanDepEffect(effect.deps[i], effect) // 删除映射表中对应的effect
        }
        effect.deps.length = effect._depsLength // 更新依赖列表的长度 归位
    }
}

class ReactiveEffect {
    _trackId = 0; // 用于记录当前effect 执行了几次 防止一个属性在当前effect中多次依赖收集
    deps = []; // 用于记录 currentEffect 依赖的属性
    _depsLength = 0; // 收集的个数

    active = true; // 是否激活 创建的effect是不是响应式的
    // fn 为用户编写的函数 如果fn里有依赖的属性变化了，就要调用scheduler 让run 执行
    constructor(public fn: Function, public scheduler: () => void) {}
    run() {
        // todo 不理解为什么要设置一个激活状态 它是干啥用的 不是激活的 执行之后 什么都不做
        // 后面有个effectScope.stop() 可以停止所有的effect不参加响应式处理
        if (!this.active) {
            return this.fn();
        }

        // 插一根旗子 让属性看到我，等回调执行完了，再拔掉，防止外部的属性进来
        let parent = activeEffect; // 记录当前激活的effect
        try {
            console.log('effect run')
            activeEffect = this; // 记录当前激活的effect

            // effect 重新执行之前，需要将上一次的依赖情况清空
            preCleanEffect(this)

            return this.fn() // 依赖收集 -> state.name state.age 变化了，就要执行回调
        } finally { 
            postCleanEffect(this)
            activeEffect = parent; // 记录当前激活的effect
        }
    }

    stop() {
        this.active = false;
    }
}

function cleanDepEffect(dep:any, effect: ReactiveEffect) {
    dep.delete(effect)
    if(dep.size === 0) {
        dep.cleanup() // 如果map为空了，就清理掉
    }
}

//  双向记忆 把effect放到收集器里，收集器收集effect ，我还想知道这个effect依赖了哪些属性
export function trackEffect(effect: ReactiveEffect, dep:any) { // 手机是一个一个手机的
    // 需要重新的去收集依赖 将不需要的移除掉
    debugger
    
    if (dep.get(effect) !== effect._trackId) {
        console.log(dep.get(effect), effect._trackId); 
        // 收集依赖
        dep.set(effect, effect._trackId)

        // console.log("优化了 多余的收集")
        let oldDep = effect.deps[effect._depsLength]
        if (oldDep !== dep) {
            if (oldDep) {
                //  删除老的
                cleanDepEffect(oldDep, effect)
            }
            // 换成新的
             effect.deps[effect._depsLength++] = dep;
        } else {
           // 相同的effect 不收集了 但是统计次数
           effect._depsLength++;
        }
    } else {
        console.log('---')
    }
    
    dep.set(effect, effect._trackId)
    // 我还想让 effect 和 dep 关联起来 effect有个数组，把dep也记住
    effect.deps[effect._depsLength++] = dep;

}

export function trackEffects(dep) {
    for (const effect of dep.keys()) {
        if (effect.scheduler) {
            effect.scheduler(); // -> effect.run()
        }
    }
}